package com.capgemini.capstore.services;

public interface CustomerServices {
	
	public void changePassword(String mobileNo, String password, String confirmPassword);

}
