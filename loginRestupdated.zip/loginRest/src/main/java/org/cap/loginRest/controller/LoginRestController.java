package org.cap.loginRest.controller;

import java.util.List;

import org.cap.loginRest.model.Customer;
import org.cap.loginRest.service.LoginService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class LoginRestController {
	@Autowired
	private LoginService loginService;
	private Customer customer;
	
	@PutMapping(value = "/customers/{id}")
	public ResponseEntity<?> updateCustomer(@PathVariable("id") int id,
			HttpSession session,
			@RequestParam("oldPassword")String oldPassword,
			@RequestParam("newPassword")String newPassword,
			@RequestParam("confirmNewPassword")String confirmNewPassword,
			@RequestBody Customer customer) 
	{
	    
	     
		int customerId=session.getAttribute("customerId");
	
		Customer cust = loginService.findById(customerId);

		if(oldPassword.equals(cust.getPassword()))
		{
			if(newPassword.equals(confirmNewPassword))
			{
				if(!oldPassword.equals(newPassword))
				{
                                         //String encrypt=loginService.encrypt(password);after using encryption
					loginService.changePassword( customerId,newPassword);//newPassword change to encrypt
				}
			}
		}
		
		 //loginService.changePassword( oldPassword,newPassword,confirmNewPassword);
		

        loginService.save(cust);
        
		return new ResponseEntity<Customer>(cust, HttpStatus.OK);
	}
	
	@PostMapping("/login")
	public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer){
		
			
		loginService.save(customer);
		
		return new ResponseEntity<Customer>(customer,HttpStatus.OK);
	}
	
	@GetMapping("/customers")
	public ResponseEntity<List<Customer>> getAllPilots(){
		List<Customer> customers= loginService.getAll();
		if(customers.isEmpty()||customers==null)
			return new ResponseEntity
				("Sorry! Pilot details not available!",HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Customer>>(customers,HttpStatus.OK);
	}

}
