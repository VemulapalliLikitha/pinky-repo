package org.cap.loginRest.dao;

import org.cap.loginRest.model.Customer;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository("loginDao")
public interface LoginDao extends JpaRepository<Customer,Integer> {

	Customer findOne(int id);

}
