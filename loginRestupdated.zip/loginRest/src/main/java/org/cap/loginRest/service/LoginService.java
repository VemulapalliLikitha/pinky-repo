package org.cap.loginRest.service;

import java.util.List;

import org.cap.loginRest.model.Customer;

public interface LoginService {
public void save(Customer customer);

public List<Customer> getAll();


public Customer findById(int id);

public void updateCustomer(Customer cust);

public void changePassword(String oldPassword, String newPassword, String confirmNewPassword);
}
