function changePwdForm(){
	var password=changePwd.password.value;
	var newPassword=changePwd.newPassword.value;
	var confirmNewPassword=changePwd.confirmNewPassword.value;
	//var validPassword=/^[A-z]{1}[A-Za-z0-9]{7,13}$/;
	var flag=false;
	if(password==""||password==null){
		alert("Please enter password");
	}
	else if(newPassword==""|| newPassword==null){
		alert("please enter new password");
	}
	/*else if(validPassword.test(newPassword)==false){
		alert("password should meet the constraints");
	}	*/
	else if(confirmNewPassword=="" || confirmNewPassword==null){
		alert("confirm password cannot be empty");
	}
	else if(newPassword!=confirmNewPassword){
		alert("new password and confirm new password should be equal");
	}
	else{
		flag=true;
		alert("password changed successfully!!");
	}
		return flag;
}
		
}