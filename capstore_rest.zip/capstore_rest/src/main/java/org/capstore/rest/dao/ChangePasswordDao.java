package org.capstore.rest.dao;

import javax.transaction.Transactional;

import org.capstore.rest.model.Merchant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository("changePwdDao")
@Transactional
public interface ChangePasswordDao extends JpaRepository<Merchant,Integer>{

	

	@Query("update Merchant m set m.password=:newPassword where m.merchantId=:merchantId")
	void updatePassword(@Param("newPassword") String newPassword,@Param("merchantId") int merchantId);

	
	@Query("SELECT m FROM Merchant m WHERE m.emailId=:emailId")
	Merchant getOneByEmailaForMerchant(@Param("emailId") String emailId);
}
