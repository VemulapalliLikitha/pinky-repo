package org.capstore.rest.service;

import java.util.List;

import org.capstore.rest.model.Customer;
import org.capstore.rest.model.Merchant;



public interface LoginService {
public void save(Customer customer);
public void save(Merchant merchant);

public Customer getOneByEmail(String email);

public List<Customer> getAll();

public Customer findById(int id);
public Merchant findByIdForMerchant(int id);

public void updateCustomer(Customer cust);

public Customer getOne(Integer fid);



public Merchant getOneByEmailForMerchant(String emailId);
}
