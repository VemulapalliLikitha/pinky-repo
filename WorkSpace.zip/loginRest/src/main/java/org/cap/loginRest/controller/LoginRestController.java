package org.cap.loginRest.controller;

import java.util.List;

import org.cap.loginRest.model.ChangePwd;
import org.cap.loginRest.model.Customer;
import org.cap.loginRest.service.LoginService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;





@RestController
@RequestMapping("/api/v1")
public class LoginRestController {
	@Autowired
	private LoginService loginService;
	private Customer customer;
	
	@GetMapping("/customers")
	public ResponseEntity<List<Customer>> getAllPilots(){
		List<Customer> customers= loginService.getAll();
		if(customers.isEmpty()||customers==null)
			return new ResponseEntity
				("Sorry! Pilot details not available!",HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Customer>>(customers,HttpStatus.OK);
	}

	
	@PostMapping("/customers")
	public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer){
		
		loginService.save(customer);
		
		return new ResponseEntity<Customer>(customer,HttpStatus.OK);
	}

	
	@GetMapping("/customers/{id}")
	public ResponseEntity<Customer> getOne(@PathVariable("id")Integer fid){
		Customer cust= loginService.getOne(fid);
		if(cust==null)
			return new ResponseEntity
					("Sorry! customer detail not available!",HttpStatus.NOT_FOUND);
		return new ResponseEntity<Customer>(cust,HttpStatus.OK);
	}

		
		/*@GetMapping("/customers/{emailId}")
			public ResponseEntity<Customer> getCustomers(@PathVariable("emailId") String email){
				System.out.println(email);
				List<Customer> customer1=loginService.getAll();
				Customer cust=new Customer();
				for (Customer c : customer1) {
					if(c.getEmailId().toString().equals(email)) {
						cust.setId(c.getId());
						
					}
				}
				return new ResponseEntity<Customer>(cust, HttpStatus.OK);
			}  
*/

	@PutMapping("/customers")
	public ResponseEntity<Customer> update(@RequestBody Customer cust){
		
		loginService.save(cust);
		
		return new ResponseEntity<Customer>(cust,HttpStatus.OK);
	}
	
	
	/*@PutMapping("/customers")
	public ResponseEntity<Customer> updateCustomer1( @RequestBody Customer cust1){
	     
		List<Customer> cust = loginService.getAll();
		Customer cust1=new Customer();
		for(Customer c: cust) {
			if(c.getEmailId().toString().equals(customer.getEmailId().toString())) {
				cust1.setId(c.getId());
				cust1.setEmailId(c.getEmailId());
				cust1.setPassword(changePwd.getNewPassword());
			}
		}
        
		loginService.save(cust1);
        return new ResponseEntity<Customer>(cust1, HttpStatus.OK);
		
	}
	
	
	
	*/
	

	/*@RequestMapping(value = "/customers/{id}", method = RequestMethod.GET)
	public ResponseEntity<Customer> getUser(@PathVariable("id") int id) {
	
		Customer cust = loginService.findById(id);
		
		return new ResponseEntity<Customer>(cust, HttpStatus.OK);
	}
	*/
	
	
	
	
	
	
	
}
