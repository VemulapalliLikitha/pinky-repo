package org.cap.loginRest.service;

import java.util.List;

import org.cap.loginRest.dao.LoginDao;
import org.cap.loginRest.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("loginService")
public class LoginServiceImpl implements LoginService{

	@Autowired
	private LoginDao loginDao;
	private Customer customer;
	
	public void save(Customer customer) {			
		
		loginDao.save(customer);
	}

	@Override
	public List<Customer> getAll() {
	
		return loginDao.findAll();
	}

	@Override
	public Customer findById(int id) {
              // id=1;
              // Customer cust=loginDao.getOne(id);
		//System.out.println(cust);
	return loginDao.getOne(id);
		
	}

	@Override
	public void updateCustomer(Customer cust) {
		
		save(cust);
		
	}

	@Override
	public Customer getOne(Integer fid) {
		
		return loginDao.getOne(fid);
	}

	

}
