package org.cap.login.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.cap.login.model.ChangePwd;
import org.cap.login.model.Customer;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

@Controller
public class MyController  {
	
	private ChangePwd changePwd;
	private Customer customer;

	@RequestMapping("/pilotForm")
	public String getAllDeatils(ModelMap map) {
		
		final String uri="http://localhost:8084/loginRest/api/v1/customers";
		RestTemplate restTemplate=new RestTemplate();
		
		Customer[] cust = restTemplate.getForObject(uri, Customer[].class);
	
	
		
		map.put("customer", cust);
		map.put("customers",new Customer());
	
		return "pilotForm";
	}
	
	
	
	@RequestMapping("/log")
	public String Details(Model model) {
		model.addAttribute("changePwd", new ChangePwd());
		return "login";
	}

	@PostMapping("/login")
	public String showDetails(ModelMap map, 
			@RequestParam("email") String email,
			@RequestParam("password") String password,
			HttpSession session,Model model) {
	
		map.put("customer", email);
		session.setAttribute("email", email);
		session.setAttribute("pass", password);
		
		model.addAttribute("changePwd", new ChangePwd());
		return "ChangePassword";
	}
	
	
	@PostMapping("/changePwd")
	public String changePwd( @RequestParam String oldPassword
			,@RequestParam String newPassword,@RequestParam String confirmNewPassword,
			HttpSession session, Model model) {
			
		changePwd.setEmailId(session.getAttribute("email").toString());
		changePwd.setOldPassword(oldPassword);
		changePwd.setNewPassword(newPassword);
		changePwd.setConfirmNewPassword(confirmNewPassword);
		
		
			final String uri="http://localhost:8084/loginRest/api/v1/customers";
			RestTemplate restTemplate=new RestTemplate();
		
		
			restTemplate.postForEntity(uri, changePwd, ChangePwd.class);
		

		
		return "login";
		
	}
	/*@PostMapping("/changePwd")
	public String updateOrder(@Valid @ModelAttribute("change")Customer cust,
			ModelMap map,
			@RequestParam("oldPassword") String oldPassword,
			@RequestParam("newPassword") String newPassword,
			@RequestParam("confirmNewPassword") String confirmNewPassword,
			HttpSession session
			) {

			final String uri="http://localhost:8084/loginRest/api/v1/customers/";
			RestTemplate restTemplate=new RestTemplate();
			Map< String, Object> params= new HashMap<>();
			params.put("oldPassword",oldPassword);
			params.put("newPassword", newPassword);
			params.put("confirmNewPassword", confirmNewPassword);
			
				restTemplate.getForObject(uri,Customer.class,params);
					
		
		return "redirect:/login";
	}
	*/
	/*
	@RequestMapping("/verify")
	public String verifyEmail(@Valid @ModelAttribute("customer") Customer email, @RequestParam("emailId") String emailId)
	{
		
		final String uri="http://localhost:8081/capstoreApp/api/v1/emails/{emailId}";
		RestTemplate restTemplate=new RestTemplate();
		Map<String, Object> params=new HashMap<>();
		params.put("emailId",emailId);
		Customer customers= restTemplate.getForObject(uri, Customer.class,params);
		if(customers.getId()==0) {
			return "redirect:forgot";
		}
		
		return "ChangePassword"; */
	
	@RequestMapping("/ChangePassword")
	public String changePassword(ModelMap map,  HttpSession session) {
		
		return "ChangePassword";
	}
	

}
